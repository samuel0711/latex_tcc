## Modelo LaTeX para monografia do curso Bacharelado em Ciência da Computação

O projeto contém os arquivos necessários para alunos de graduação escreverem o projeto de conclusão de curso com o LaTeX.
Foram criados textos de exemplo para facilitar a compreensão da estrutura.

### Agradecimentos
Este modelo foi gerado utilizando como base o modelo do DCC/UFRJ.
